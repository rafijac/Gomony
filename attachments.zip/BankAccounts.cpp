#include <iostream>
#include <time.h>
using namespace std;

enum TRANSACTION_TYPE { DEPOSIT, WITHDRAWAL };

enum Month { JAN = 1, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC };
struct Date {
	Month month;
	int day;
	int year;
};

bool Equal(const Date& date1, const Date& date2)
{
	return date1.month == date2.month && date1.day == date2.day && date1.year == date2.year;
}

Date today = { DEC, 24, 2018 };
	
struct Transaction {
	TRANSACTION_TYPE type;
	int amount;
	Date date;
	int location;
};

struct CustomerAccount {
	char firstName[20];
	char lastName[20];
	Date accountDate;

	int accountNumber;
	char pin[10];

	float balance;

	int ntransactions;
	Transaction transactions[100];
};

int main()
{
	CustomerAccount* GetAccount(CustomerAccount[], int naccounts, int account);

	CustomerAccount accounts[] = {
		{"Homer", "Simpson", { JAN, 1, 2001 }, 111, "111", 0.0, 0},
		{"Marge", "Simpson", { FEB, 2, 2002 }, 222, "222", 0.0, 0},
		{"Bart", "Simpson", { MAR, 3, 2003 }, 333, "333", 0.0, 0},
		{"Lisa", "Simpson", { APR, 4, 2004 }, 444, "444", 0.0, 0},
		{"Maggie", "Simpson", { MAY, 5, 2005 }, 555, "555", 0.0, 0 }
	};

	int naccounts = sizeof(accounts) / sizeof(CustomerAccount);

	srand(time(nullptr));
	cout << "Swipe your card" << endl;
	CustomerAccount* acct = &accounts[rand() % naccounts];
	cout << "Welcome " << acct->firstName << endl;

	// loop until correct pin is received
	char pin[10] = "";
	while (strcmp(pin, acct->pin) != 0) {
		cout << "Enter pin number: ";
		cin >> pin;
	}

	// print usage
	cout << "Select one of the following" << endl;
	cout << "  1 display account balance" << endl;
	cout << "  2 deposit amount" << endl;
	cout << "  3 withdrawal amount" << endl;
	cout << "  4 print transaction" << endl;
	cout << "  5 admin" << endl;
	cout << "  0 quit" << endl;

	enum Action {QUIT, BALANCE, DEP, WITH, TRANSACTIONS, ADMIN};

	// loop until quit is entered
	bool quit = false;
	while (!quit) {
		int selection;
		cin >> selection;
		switch (selection) {
		case QUIT:
			quit = true;
			break;

		case BALANCE:
			cout << "current balance is: " << acct->balance << endl;
			break;

		case DEP:
			void HandleDeposit(CustomerAccount*);

			HandleDeposit(acct);
			break;

		case WITH:
			void HandleWithdrawal(CustomerAccount*);

			HandleWithdrawal(acct);
			break;

		case TRANSACTIONS: {
			void HandleDailyTransaction(CustomerAccount*);
			HandleDailyTransaction(acct);

			break;
		}

		case ADMIN:
			void HandleAdmin(const CustomerAccount[], int naccounts);
			HandleAdmin(accounts, naccounts);

			break;

		default:
			cout << "illegal selection" << endl;
			break;
		}
	}

	return 0;
}

CustomerAccount* GetAccount(CustomerAccount accounts[], int naccounts, int accountNumber)
{
	for (int i = 0; i < naccounts; i++)
		if (accounts[i].accountNumber == accountNumber)
			return &accounts[i];

	return nullptr;
}

void HandleDeposit(CustomerAccount* acct)
{
	int amount;

	cout << "Enter deposit amount: ";
	cin >> amount;
	acct->balance = acct->balance + amount;

	Transaction& transaction = acct->transactions[acct->ntransactions++];
	transaction.type = DEPOSIT;
	transaction.amount = amount;
	transaction.date = today;
	transaction.location = rand() % 10 + 1;
}

void HandleWithdrawal(CustomerAccount* acct)
{
	int amount;

	cout << "Enter withdrawal amount: ";

	// check for sufficient funds
	cin >> amount;
	if (amount > acct->balance) {
		cout << "insufficient funds" << endl;
		return;
	}

	acct->balance = acct->balance - amount;

	Transaction& transaction = acct->transactions[acct->ntransactions++];
	transaction.type = WITHDRAWAL;
	transaction.amount = amount;
	transaction.date = today;
	transaction.location = rand() % 10 + 1;
}

void HandleDailyTransaction(CustomerAccount* acct)
{

	char* types[] = { "deposit", "withdrawal" };
	cout << "Enter date: ";
	Date date;

	int month;
	cin >> month >> date.day >> date.year;
	date.month = (Month)month;

	for (int i = 0; i < acct->ntransactions; i++) {
		Transaction* tr = &acct->transactions[i];
		if (Equal(date, tr->date))
			cout << types[tr->type] << ' ' << tr->amount << endl;
	}
}

void HandleAdmin(const CustomerAccount accounts[], int naccounts)
{
	char* types[] = { "deposit", "withdrawal" };

	for (int loc = 1; loc < 10; loc++) {
		cout << "Location " << loc << endl;

		for (int i = 0; i < naccounts; i++) {
			const CustomerAccount* acct = &accounts[i];
			for (int j = 0; j < acct->ntransactions; j++) {
				const Transaction* tr = &acct->transactions[j];
				if (tr->location == loc)
					cout << "  " << types[tr->type] << ' ' << tr->amount << endl;
			}
		}
	}
}