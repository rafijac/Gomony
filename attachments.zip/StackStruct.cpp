#include <iostream>
using namespace std;

struct Stack {
	int capacity;
	int size;
	int* elements;
};

void Push(Stack& stack, int val);
void Pop(Stack& stack);
int Top(Stack& stack);
void Print(Stack& stack);

//void Push(int*& stack, int& capacity, int& size, int val);
//void Pop(int*& stack, int& size);
//int Top(int* stack, int size);
//void Print(int*& stack, int& capacity, int& size); 

int main()
{
	Stack stack;

	stack.size = 0;
	stack.capacity = 1;
	stack.elements = new int[1];

	while (true) {
		cout << "Enter command (push, pop, top, print, quit)" << endl;
		char op[10];
		cin >> op;

		if (!strcmp(op, "quit"))
			return 0;

		else if (!strcmp(op, "push")) {
			int val;
			cin >> val;
			Push(stack, val);
		}

		else if (!strcmp(op, "pop")) {
			Pop(stack);
		}

		else if (!strcmp(op, "top")) {
			int top = Top(stack);
			if (top != -1)
				cout << top << endl;
		}

		else if (!strcmp(op, "print"))
			Print(stack);
	}

	system("pause");
	return 0;
}

// stack is reallocated when capacity is reached
void Push(Stack& stack, int val)
{
	void Copy(const int*, int, int*);

	// handle overflow capacity
	if (stack.size == stack.capacity) {
		int* elements = stack.elements;

		// double capacity, create new stack, and copy original
		stack.capacity *= 2;
		stack.elements = new int[stack.capacity];
		Copy(elements, stack.size, stack.elements);

		delete[] elements;
	}

	//  insert val at top of stack
	stack.elements[stack.size] = val;

	// and increment size
	stack.size++;
}

// note: we do not shrink stack
void Pop(Stack& stack)
{
	if (stack.size == 0)
		cout << "empty stack" << endl;

	else
		stack.size--;
}

int Top(Stack& stack)
{
	if (stack.size == 0) {
		cout << "empty stack" << endl;
		return -1; // need to throw exception
	}

	return stack.elements[stack.size - 1];
}

void Print(Stack& stack)
{
	for (int* p = stack.elements; p < stack.elements + stack.size; p++)
		cout << *p << ' ';

	cout << "(capacity: " << stack.capacity << ')' << endl;
}

void Copy(const int* stack1, int size, int* stack2)
{
	for (int i = 0; i < size; i++)
		*stack2++ = *stack1++;
}
